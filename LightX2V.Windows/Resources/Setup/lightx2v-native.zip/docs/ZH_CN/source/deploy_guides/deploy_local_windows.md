# Windows 本地部署指南

## 📖 概述

本文档将详细指导您在Windows环境下完成LightX2V的本地部署配置，包括批处理文件推理、Gradio Web界面推理等多种使用方式。

## 🚀 快速开始

### 环境要求

#### 硬件要求
- **GPU**: NVIDIA GPU，建议 8GB+ VRAM
- **内存**: 建议 16GB+ RAM
- **存储**: 强烈建议使用 SSD 固态硬盘，机械硬盘会导致模型加载缓慢

## 🎯 使用方式

### 方式一：使用批处理文件推理

参考[快速开始文档](../getting_started/quickstart.md)安装环境，并使用[批处理文件](https://github.com/ModelTC/LightX2V/tree/main/scripts/win)运行。

### 方式二：使用Gradio Web界面推理

#### 手动配置Gradio

参考[快速开始文档](../getting_started/quickstart.md)安装环境，参考[Gradio部署指南](./deploy_gradio.md)

#### 旧版整合包：一键启动 Gradio

以下保留旧版整合包的下载和使用说明。新独立应用的安装与启动见 [Gradio-Lightx2v](https://github.com/ModelTC/Gradio-Lightx2v)；当前尚未提供对应的新整合包，不能将以下环境直接视为新应用的部署方案。

**📦 下载软件包**
- [夸克网盘](https://pan.quark.cn/s/f44023dcf8c8)


**📁 目录结构**
解压后，确保目录结构如下：

```
├── env/                        # LightX2V 环境目录
├── LightX2V/                   # LightX2V 项目目录
├── start_lightx2v.bat          # 一键启动脚本
├── lightx2v_config.txt         # 配置文件
├── LightX2V使用说明.txt         # LightX2V使用说明
├── outputs/                    # 生成的视频保存目录
└── models/                     # 模型存放目录
```

**RTX 50系显卡用户注意**：我们提供了专用的运行环境。请从[夸克网盘](https://pan.quark.cn/s/52b9a8c8f07a)下载，解压后替换软件包中的 `env/` 目录即可。

**📥 下载模型**:

可直接从gradio前端下载，提供了两个下载源，huggingface和modelscope，可根据自己情况选择，或参考[模型结构文档](../getting_started/model_structure.md)手动下载


**📋 配置参数**

编辑 `lightx2v_config.txt` 文件，根据需要修改以下参数：

```ini

# 界面语言 (zh: 中文, en: 英文)
lang=zh

# 服务器端口
port=8032

# GPU设备ID (0, 1, 2...)
gpu=0

# 模型路径
model_path=models/
```

**🚀 启动服务**

双击运行 `start_lightx2v.bat` 文件，脚本将：
1. 自动读取配置文件
2. 验证模型路径和文件完整性
3. 启动 Gradio Web 界面
4. 自动打开浏览器访问服务


![Gradio中文界面](../../../../assets/figs/portabl_windows/pic_gradio_zh.png)

**⚠️ 重要提示**:
- **页面显示问题**: 旧版整合包请按随包说明排查。新独立应用使用 Gradio 5.50.0，安装方式见新仓库。
