import argparse
import os

import torch.distributed as dist
from loguru import logger

from lightx2v.models.runners.runner_factory import build_runner
from lightx2v.utils.envs import *
from lightx2v.utils.profiler import *
from lightx2v.utils.set_config import build_cli_inputs, init_parallel, print_config, print_request
from lightx2v.utils.utils import validate_config_paths
from lightx2v_platform.registry_factory import PLATFORM_DEVICE_REGISTER


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=None, help="The seed for random generator")
    parser.add_argument(
        "--model_cls",
        type=str,
        required=True,
        choices=[
            "wan2.1",
            "wan2.1_vace",
            "wan2.1_sf",
            "seko_talk",
            "wan2.2_moe",
            "lingbot_world",
            "wan2.2",
            "wan2.2_moe_vace",
            "qwen_image",
            "longcat_image",
            "wan2.2_animate",
            "hunyuan_video_1.5",
            "worldplay_distill",
            "worldplay_ar",
            "worldplay_bi",
            "z_image",
            "flux2",
            "ltx2",
            "bagel",
            "seedvr2",
            "neopp",
            "lingbot_world_fast",
            "worldmirror",
        ],
    )
    parser.add_argument(
        "--task",
        type=str,
        choices=["t2v", "i2v", "t2i", "i2i", "flf2v", "vace", "animate", "s2v", "rs2v", "t2av", "i2av", "ltx2_s2v", "sr", "recon"],
        required=True,
    )
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--config_json", type=str, required=True)
    parser.add_argument("--prompt", type=str, default=None, help="The input prompt for text-to-video generation")
    parser.add_argument("--negative_prompt", type=str, default=None)
    parser.add_argument(
        "--image_path",
        type=str,
        default=None,
        help="The path to input image file(s) for image-to-video (i2v) or image-to-audio-video (i2av) task. Multiple paths should be comma-separated. Example: 'path1.jpg,path2.jpg'",
    )
    parser.add_argument("--last_frame_path", type=str, default=None, help="The path to last frame file for first-last-frame-to-video (flf2v) task")
    parser.add_argument(
        "--audio_path",
        type=str,
        default=None,
        help="Input audio path: Wan s2v / rs2v, or required for LTX-2 task ltx2_s2v.",
    )
    parser.add_argument("--video_path", type=str, default=None, help="Input video path.")
    parser.add_argument(
        "--image_strength",
        type=str,
        default=None,
        help="i2av: single float, or comma-separated floats (one per image, or one value broadcast). Example: 1.0 or 1.0,0.85,0.9",
    )
    parser.add_argument(
        "--image_frame_indices",
        type=str,
        default=None,
        help="i2av: comma-separated pixel frame indices (one per image). Omit or empty to evenly space frames in [0, num_frames-1]. Example: 0,40,80",
    )
    # [Warning] For vace task, need refactor.
    parser.add_argument(
        "--ref_image_paths",
        type=str,
        default=None,
        help="The file list of the source reference images. Separated by ','. Default None.",
    )
    parser.add_argument("--mask_path", type=str, default=None, help="Input mask path.")
    parser.add_argument(
        "--pose_video_path",
        type=str,
        default=None,
        help="The file of the source pose. Default None.",
    )
    parser.add_argument(
        "--face_video_path",
        type=str,
        default=None,
        help="The file of the source face. Default None.",
    )
    parser.add_argument(
        "--background_video_path",
        type=str,
        default=None,
        help="The file of the source background. Default None.",
    )
    parser.add_argument(
        "--pose",
        type=str,
        default=None,
        help="Pose string (e.g., 'w-3, right-0.5') or JSON file path for WorldPlay models.",
    )
    parser.add_argument(
        "--action_path",
        type=str,
        default=None,
        help="Directory path for lingbot camera/action control files (poses.npy, intrinsics.npy, optional action.npy).",
    )
    # WorldMirror (3D reconstruction) specific
    parser.add_argument("--input_path", type=str, default=None, help="(worldmirror/recon) Path to a directory of images, a video file, or a single image.")
    parser.add_argument("--strict_output_path", type=str, default=None, help="(worldmirror/recon) If set, write outputs directly here instead of under save_result_path/<subdir>/<timestamp>/.")
    parser.add_argument("--prior_cam_path", type=str, default=None, help="(worldmirror/recon) Optional camera prior JSON (extrinsics + intrinsics).")
    parser.add_argument("--prior_depth_path", type=str, default=None, help="(worldmirror/recon) Optional depth prior directory (one .npy/.png per image).")
    parser.add_argument("--save_rendered", action="store_true", default=None, help="(worldmirror/recon) Render an interpolated fly-through video from Gaussian splats.")
    parser.add_argument("--render_interp_per_pair", type=int, default=None, help="(worldmirror/recon) Interpolated frames per camera pair for --save_rendered.")
    parser.add_argument("--render_depth", action="store_true", default=None, help="(worldmirror/recon) Also render a depth video with --save_rendered.")

    parser.add_argument("--save_result_path", type=str, default=None, help="The path to save video path/file")
    parser.add_argument("--return_result_tensor", action="store_true", default=None, help="Whether to return result tensor. (Useful for comfyui)")
    parser.add_argument("--size", type=int, nargs="+", default=None, help="Output size in pixels: HEIGHT WIDTH")
    parser.add_argument("--num_frames", type=int, default=None, help="Requested output frame count. Model-specific length constraints apply.")
    parser.add_argument("--aspect_ratio", type=str, default=None)
    parser.add_argument("--sr_ratio", type=float, default=None, help="super resolution ratio for sr task")

    args = parser.parse_args()
    startup_config, request_data = build_cli_inputs(args)
    if startup_config["parallel"]:
        platform_device = PLATFORM_DEVICE_REGISTER.get(os.getenv("PLATFORM", "cuda"), None)
        platform_device.init_parallel_env()
        init_parallel(startup_config)

    print_config(startup_config, title="Startup config")

    validate_config_paths(startup_config)

    with ProfilingContext4DebugL1("Total Cost"):
        runner = build_runner(startup_config)
        input_info = runner.prepare_request(request_data)
        print_request(input_info, runner.get_supported_request_fields(input_info.task))
        runner.run_request(input_info)

    # Clean up distributed process group
    if dist.is_initialized():
        dist.destroy_process_group()
        logger.info("Distributed process group cleaned up")


if __name__ == "__main__":
    main()
