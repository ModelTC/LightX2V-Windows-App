"""
Base model class for all transformer models in the networks module.

This base class provides common functionality for:
- Weight loading (original and quantized)
- CPU offloading
- Lazy loading
- Distributed weight loading
- Inference setup
"""

import gc
import glob
import json
import os
import struct
from abc import ABC, abstractmethod

import torch
import torch.distributed as dist
from loguru import logger
from safetensors import safe_open

from lightx2v.common.offload.shared_weight_coordinator import coordinate_rank_local_error
from lightx2v.common.offload.shared_weight_map import validate_shared_operator_views
from lightx2v.utils.envs import *
from lightx2v.utils.ggml_tensor import load_gguf_sd_ckpt
from lightx2v.utils.utils import *
from lightx2v_platform.base.global_var import AI_DEVICE

SAFETENSORS_DTYPE_MAP = {
    "F64": torch.float64,
    "F32": torch.float32,
    "F16": torch.float16,
    "BF16": torch.bfloat16,
    "I64": torch.int64,
    "I32": torch.int32,
    "I16": torch.int16,
    "I8": torch.int8,
    "U8": torch.uint8,
    "BOOL": torch.bool,
    "F8_E4M3": torch.float8_e4m3fn,
    "F8_E5M2": torch.float8_e5m2,
}


class BaseTransformerModel(ABC):
    """Base class for all transformer models.

    This class provides common functionality that can be shared across
    different model implementations (z_image, qwen_image, ltx2, etc.).

    Subclasses should define:
    - pre_weight_class: Class for pre-inference weights
    - transformer_weight_class: Class for transformer weights
    - post_weight_class: Class for post-inference weights (if applicable)
    """

    # These should be overridden by subclasses
    pre_weight_class = None
    transformer_weight_class = None
    post_weight_class = None

    def __init__(self, model_path, config, device, model_type=None, lora_path=None, lora_strength=1.0):
        """Initialize the base transformer model.

        Args:
            model_path: Path to model directory
            config: Configuration dictionary
            device: Device to use
            model_type: Model type (optional)
            lora_path: Path to LoRA weights (optional)
            lora_strength: LoRA strength (optional)
        """
        super().__init__()
        self.device = device
        self.model_path = model_path
        self.lora_path = lora_path
        self.lora_strength = lora_strength
        self.model_type = model_type
        if not hasattr(self, "remove_keys"):
            self.remove_keys = []
        self.sensitive_layer = {}

        self.config = config
        self.cpu_offload = self.config.get("cpu_offload", False)
        self.offload_granularity = self.config.get("offload_granularity", "block")
        if self.config["seq_parallel"]:
            self.seq_p_group = self.config.get("device_mesh").get_group(mesh_dim="seq_p")
        else:
            self.seq_p_group = None
        self.lazy_load = self.config.get("lazy_load", False)
        self.clean_cuda_cache = self.config.get("clean_cuda_cache", False)
        self.dit_quantized = self.config.get("dit_quantized", False)
        if self.dit_quantized:
            self._check_dit_quantized()
        self._init_tensor_parallel()
        from lightx2v.common.offload.block_loader import validate_contiguous_config
        from lightx2v_platform.ops.offload import get_block_offload_backend

        validate_contiguous_config(self.config, lora_path)
        self._checkpoint_metadata = None
        if self.cpu_offload and self.offload_granularity == "block":
            backend = get_block_offload_backend(required=False)
            if backend is not None:
                backend.prepare()
            if self.config.get("cpu_offload_block_contiguous", False) or (backend is not None and backend.validate_checkpoint):
                self._checkpoint_metadata = {}

    def _init_tensor_parallel(self):
        if self.config.get("tensor_parallel", False):
            self.use_tp = True
            self.tp_group = self.config.get("device_mesh").get_group(mesh_dim="tensor_p")
            self.tp_rank = dist.get_rank(self.tp_group)
            self.tp_size = dist.get_world_size(self.tp_group)
        else:
            self.use_tp = False
            self.tp_group = None
            self.tp_rank = 0
            self.tp_size = 1

    def _check_dit_quantized(self):
        """Check if the model is quantized.

        Returns:
            bool: True if the model is quantized
        """
        assert self.config.get("dit_quant_scheme", "Default") in [
            "fp8-rocm",
            "int8-rocm",
            "fp8-pertensor",
            "fp8-musa",
            "fp8-triton",
            "int8-triton",
            "fp8-vllm",
            "int8-vllm",
            "int8-metal",
            "int8-vllm-hygon-dcu",
            "fp8-q8f",
            "int8-q8f",
            "int8-convrot",
            "fp8-b128-deepgemm",
            "fp8-f16-accum",
            "fp8-sgl",
            "int8-sgl",
            "int8-torchao",
            "fp8-torchao",
            "nvfp4",
            "mxfp4",
            "mxfp6-mxfp8",
            "mxfp8",
            "int8-tmo",
            "gguf-Q8_0",
            "gguf-Q6_K",
            "gguf-Q5_K_S",
            "gguf-Q5_K_M",
            "gguf-Q5_0",
            "gguf-Q5_1",
            "gguf-Q4_K_S",
            "gguf-Q4_K_M",
            "gguf-Q4_0",
            "gguf-Q4_1",
            "gguf-Q3_K_S",
            "gguf-Q3_K_M",
            "int8-npu",
            "fp8-intel-xpu",
            "int8-intel-xpu",
            "int8-iluvatar",
        ]

    @abstractmethod
    def _init_infer_class(self):
        """Initialize inference class references.

        Subclasses should override this to set their specific inference classes.
        """
        pass

    @staticmethod
    def _read_safetensors_metadata(file_path):
        """Read tensor metadata (names, shapes, dtypes) from safetensors file header without loading data.

        Supports two kinds of safetensors files:
        1. Full model files: metadata is extracted from normal tensor header entries.
        2. Lightweight dummy-meta files (exported by tools/convert/export_dummy_meta.py):
           all tensor metadata is stored in ``__metadata__._tensor_meta`` as a JSON string,
           with ``__metadata__._is_dummy_meta == "true"`` as the marker.
        """
        with open(file_path, "rb") as f:
            header_size = struct.unpack("<Q", f.read(8))[0]
            header_json = f.read(header_size).decode("utf-8")
        header = json.loads(header_json)

        metadata = header.get("__metadata__", {})
        if metadata.get("_is_dummy_meta") == "true" and "_tensor_meta" in metadata:
            return json.loads(metadata["_tensor_meta"])

        tensors = {}
        for key, info in header.items():
            if key == "__metadata__":
                continue
            tensors[key] = {"shape": info["shape"], "dtype": info["dtype"]}
        return tensors

    def _load_dummy_ckpt(self, unified_dtype, sensitive_layer):
        """Generate random weight dict by reading safetensors metadata, without loading actual pretrained data.

        When dummy_model is enabled, this reads only the file headers to determine tensor names/shapes,
        then allocates random tensors on self.device (derived from AI_DEVICE / cpu_offload).
        """
        dummy_device = str(self.device)
        logger.info(f"[DummyModel] Generating random weights on device={dummy_device}")

        if self.config.get("dit_original_ckpt", None):
            safetensors_path = self.config["dit_original_ckpt"]
        elif self.config.get("dit_quantized_ckpt", None) and self.dit_quantized:
            safetensors_path = self.config["dit_quantized_ckpt"]
        else:
            safetensors_path = self.model_path

        if os.path.isdir(safetensors_path):
            safetensors_files = glob.glob(os.path.join(safetensors_path, "*.safetensors"))
        else:
            safetensors_files = [safetensors_path]

        remove_keys = self.remove_keys if hasattr(self, "remove_keys") else []
        preserve_keys = self.preserved_keys if hasattr(self, "preserved_keys") else None

        weight_dict = {}
        for file_path in safetensors_files:
            if self.config.get("adapter_model_path", None) is not None:
                if self.config["adapter_model_path"] == file_path:
                    continue
            logger.info(f"[DummyModel] Reading metadata from {file_path}")
            tensors_meta = self._read_safetensors_metadata(file_path)
            for key, meta in tensors_meta.items():
                if any(rk in key for rk in remove_keys):
                    continue
                if preserve_keys is not None and not any(pk in key for pk in preserve_keys):
                    continue
                shape = meta["shape"]
                st_dtype_str = meta["dtype"]
                if unified_dtype or all(s not in key for s in sensitive_layer):
                    dtype = GET_DTYPE()
                else:
                    dtype = GET_SENSITIVE_DTYPE()
                original_dtype = SAFETENSORS_DTYPE_MAP.get(st_dtype_str)
                if original_dtype is not None and not original_dtype.is_floating_point:
                    dtype = original_dtype
                weight_dict[key] = torch.randn(shape, dtype=dtype, device=dummy_device) if dtype.is_floating_point else torch.zeros(shape, dtype=dtype, device=dummy_device)

        return weight_dict

    def _init_weights(self, weight_dict=None):
        if not self.config.get("shared_cpu_weights", False):
            self._init_weights_impl(weight_dict)
            return

        try:
            local_error = None
            try:
                self._init_weights_impl(weight_dict)
            except Exception as error:
                local_error = error
            coordinate_rank_local_error("model initialization", local_error)
        except BaseException:
            try:
                self.close_shared_cpu_weights()
            except Exception as cleanup_error:
                logger.error(f"Failed to close shared CPU weight arena after coordinated initialization error: {cleanup_error}")
            raise

    def _init_weights_impl(self, weight_dict=None):
        unified_dtype = GET_DTYPE() == GET_SENSITIVE_DTYPE()
        # Some layers run with float32 to achieve high accuracy
        sensitive_layer = self.sensitive_layer
        shared_owner = None
        if weight_dict is None:
            if self.config.get("shared_cpu_weights", False):
                if self.config.get("dummy_model", False):
                    raise ValueError("shared_cpu_weights does not support dummy_model")
                weight_dict = self._load_shared_cpu_weights(unified_dtype, sensitive_layer)
                shared_owner = weight_dict.owner
                self._shared_cpu_weight_owner = shared_owner
            elif self.config.get("dummy_model", False):
                weight_dict = self._load_dummy_ckpt(unified_dtype, sensitive_layer)
                if hasattr(self, "_load_adapter_ckpt"):
                    weight_dict.update(self._load_adapter_ckpt())
            else:
                is_weight_loader = self._should_load_weights()
                if is_weight_loader:
                    if not self.dit_quantized:
                        # Load original weights
                        weight_dict = self._load_ckpt(unified_dtype, sensitive_layer)
                    else:
                        # Load quantized weights
                        weight_dict = self._load_quant_ckpt(unified_dtype, sensitive_layer)

                if (self.config.get("device_mesh") is not None and self.config.get("load_from_rank0", False)) or (hasattr(self, "use_tp") and self.use_tp):
                    if self._checkpoint_metadata is not None:
                        checkpoint_metadata = [self._checkpoint_metadata if is_weight_loader else None]
                        dist.broadcast_object_list(checkpoint_metadata, src=0)
                        self._checkpoint_metadata = checkpoint_metadata[0]
                    weight_dict = self._load_weights_from_rank0(weight_dict, is_weight_loader)

                if hasattr(self, "_load_adapter_ckpt"):
                    weight_dict.update(self._load_adapter_ckpt())

            self.original_weight_dict = weight_dict
        else:
            self.original_weight_dict = weight_dict
            if self._checkpoint_metadata is not None:
                self._record_checkpoint_metadata(weight_dict)

        self.pre_weight = self.pre_weight_class(self.config)
        if self.lazy_load:
            self.transformer_weights = self.transformer_weight_class(self.config, self.lazy_load_path, self.lora_path)
        else:
            self.transformer_weights = self.transformer_weight_class(self.config)
        if self.post_weight_class is not None:
            self.post_weight = self.post_weight_class(self.config)

        if not self._should_init_empty_model():
            self._apply_weights()

        if shared_owner is not None:
            self._validate_shared_cpu_weights(weight_dict)

    def _load_shared_cpu_weights(self, unified_dtype, sensitive_layer):
        """Return a model-specific mapping backed by a shared arena."""
        raise NotImplementedError(f"{type(self).__name__} does not implement shared CPU weight loading")

    def _validate_shared_cpu_weights(self, weight_map):
        validate_shared_operator_views(weight_map, self.transformer_weights.blocks.state_dict())
        arena = weight_map.owner.arena
        logger.info("[SharedCPUWeightsInfo] Validated {} {} tensor views in {:.3f} GiB arena", len(arena.manifest.tensors), type(self).__name__, arena.nbytes / 1024**3)

    def close_shared_cpu_weights(self):
        """Release the shared arena after all model transfers have stopped."""

        owner = self.__dict__.get("_shared_cpu_weight_owner")
        if owner is None:
            return
        owner.close()
        del self._shared_cpu_weight_owner

    @abstractmethod
    def _init_infer(self):
        """Initialize inference modules.

        Subclasses should override this to set up their specific inference modules.
        """
        pass

    def _init_offload_manager(self):
        self.transformer_infer.offload_manager.init_cuda_buffer(self.transformer_weights.offload_block_cuda_buffers, self.transformer_weights.offload_phase_cuda_buffers)
        if self.lazy_load:
            self.transformer_infer.offload_manager.init_cpu_buffer(self.transformer_weights.offload_block_cpu_buffers, self.transformer_weights.offload_phase_cpu_buffers)
        if self.config.get("cpu_offload_block_contiguous", False):
            self.transformer_infer.offload_manager.init_contiguous_group(self.transformer_weights.offload_group)

    def _should_init_empty_model(self):
        """Determine if model should be initialized empty (for LoRA).

        Returns:
            bool: True if model should be initialized empty
        """
        if self.config.get("lora_configs") and self.config["lora_configs"] and not self.config.get("lora_dynamic_apply", False):
            return True
        return False

    def _should_load_weights(self):
        """Determine if current rank should load weights from disk.

        Returns:
            bool: True if current rank should load weights
        """
        if self.config.get("device_mesh") is None:
            # Single GPU mode
            return True
        elif (dist.is_available() and dist.is_initialized()):
            if self.use_tp or self.config.get("load_from_rank0", False):
                # TP or explicit rank0-only loading: only rank 0 reads from disk
                return dist.get_rank() == 0
            return True
        return False

    def _apply_weights(self, weight_dict=None):
        """Apply weights to weight containers.

        Args:
            weight_dict: Optional weight dictionary to apply
        """
        if weight_dict is not None:
            self.original_weight_dict = weight_dict
            if self._checkpoint_metadata is not None:
                self._checkpoint_metadata.clear()
                self._record_checkpoint_metadata(weight_dict)
            del weight_dict
            gc.collect()

        if self._checkpoint_metadata is not None:
            from lightx2v.common.offload.block_loader import prepare_contiguous_group, validate_group_checkpoints

            group = self.transformer_weights.offload_group
            if self.config.get("cpu_offload_block_contiguous", False):
                prepare_contiguous_group(group, self.original_weight_dict, self._checkpoint_metadata)
            elif group is not None and not self.lazy_load and not self.config.get("dummy_model"):
                validate_group_checkpoints(group, self._checkpoint_metadata)

        # Load weights into containers
        self.pre_weight.load(self.original_weight_dict)
        self.transformer_weights.load(self.original_weight_dict)
        if hasattr(self, "post_weight"):
            self.post_weight.load(self.original_weight_dict)

        # Handle LoRA if needed
        if self.config.get("lora_dynamic_apply", False) and self.lora_path is not None:
            assert self.config.get("lora_configs", False)
            if hasattr(self, "_register_lora"):
                self._register_lora(self.lora_path, self.lora_strength)

        del self.original_weight_dict
        if self._checkpoint_metadata is not None:
            self._checkpoint_metadata.clear()
        device_module = getattr(torch, AI_DEVICE, None)
        if device_module is not None and hasattr(device_module, "empty_cache"):
            device_module.empty_cache()
        gc.collect()

    def _load_lora_file(self, file_path, dtype=None):
        dtype = GET_DTYPE() if dtype is None else dtype
        if self.device.type != "cpu" and (dist.is_available() and dist.is_initialized()):
            device = f"{AI_DEVICE}:{dist.get_rank()}"
        else:
            device = str(self.device)

        prefixes_to_remove = ["diffusion_model.", "transformer.", "model.diffusion_model."]

        def remove_prefix(key):
            return_key = key
            for prefix in prefixes_to_remove:
                if key.startswith(prefix):
                    return_key = key[len(prefix) :]
            if "lora_A" in return_key:
                return_key = return_key.replace("lora_A", "lora_down")
            if "lora_B" in return_key:
                return_key = return_key.replace("lora_B", "lora_up")
            return return_key

        if device == "cpu":
            with safe_open(file_path, framework="pt", device=device) as f:
                tensor_dict = {remove_prefix(key): f.get_tensor(key).to(dtype).pin_memory() for key in f.keys()}
        else:
            with safe_open(file_path, framework="pt", device=device) as f:
                tensor_dict = {remove_prefix(key): f.get_tensor(key).to(dtype) for key in f.keys()}
        return tensor_dict

    def _register_lora(self, lora_path, strength):
        lora_weight = self._load_lora_file(lora_path)
        self.pre_weight.register_lora(lora_weight, strength)
        self.transformer_weights.register_lora(lora_weight, strength)
        self.pre_weight.register_diff(lora_weight)
        self.transformer_weights.register_diff(lora_weight)

    def _update_lora(self, lora_path, strength):
        if isinstance(lora_path, dict):
            lora_weight = lora_path
        else:
            lora_weight = self._load_lora_file(lora_path)
        self.pre_weight.update_lora(lora_weight, strength)
        self.transformer_weights.update_lora(lora_weight, strength)
        if hasattr(self, "post_weight"):
            self.post_weight.update_lora(lora_weight, strength)

    def _remove_lora(self):
        self.pre_weight.remove_lora()
        self.transformer_weights.remove_lora()
        if hasattr(self, "post_weight"):
            self.post_weight.remove_lora()

    def _record_checkpoint_metadata(self, tensors):
        if getattr(self, "_checkpoint_metadata", None) is None:
            return
        from lightx2v_platform.ops.offload.weight_storage import TensorMetadata

        for name in tensors.keys():
            if name in self._checkpoint_metadata:
                raise ValueError(f"Duplicate checkpoint weight: {name}")
            if hasattr(tensors, "get_slice"):
                view = tensors.get_slice(name)
                dtype = SAFETENSORS_DTYPE_MAP.get(view.get_dtype())
                if dtype is None:
                    dtype = tensors.get_tensor(name).dtype
                self._checkpoint_metadata[name] = TensorMetadata(tuple(view.get_shape()), dtype)
            elif isinstance(tensors[name], torch.Tensor):
                tensor = tensors[name]
                self._checkpoint_metadata[name] = TensorMetadata(tuple(tensor.shape), tensor.dtype)

    def _load_safetensor_to_dict(self, file_path, unified_dtype, sensitive_layer):
        """Load a safetensors file into a dictionary.

        Args:
            file_path: Path to safetensors file
            unified_dtype: Whether to use unified dtype
            sensitive_layer: Dictionary of sensitive layer patterns

        Returns:
            dict: Dictionary of tensors
        """
        remove_keys = self.remove_keys if hasattr(self, "remove_keys") else []
        preserve_keys = self.preserved_keys if hasattr(self, "preserved_keys") else None  # None means all keys are preserved, otherwise only keys in preserve_keys are preserved

        # In PipeFusion mode, load weights to CPU first to avoid OOM — each
        # stage only needs a subset of block weights on GPU.
        if self.config.get("pipefusion_parallel", False):
            device = "cpu"
        elif self.device.type != "cpu" and (dist.is_available() and dist.is_initialized()):
            device = dist.get_rank()
        else:
            device = str(self.device)

        ext = os.path.splitext(file_path)[-1]
        if ext in (".pt", ".pth", ".tar"):
            state_dict = torch.load(file_path, map_location="cpu", weights_only=True)
            if isinstance(state_dict, dict) and "state_dict" in state_dict:
                state_dict = state_dict["state_dict"]
            self._record_checkpoint_metadata(state_dict)
            return {
                key: (tensor.to(device=device, dtype=GET_DTYPE()) if unified_dtype or all(s not in key for s in sensitive_layer) else tensor.to(device=device, dtype=GET_SENSITIVE_DTYPE()))
                for key, tensor in state_dict.items()
                if isinstance(tensor, torch.Tensor)
                and not any(remove_key in key for remove_key in remove_keys)
                and (preserve_keys is None or any(preserve_key in key for preserve_key in preserve_keys))
            }

        with safe_open(file_path, framework="pt", device=device) as f:
            self._record_checkpoint_metadata(f)
            return {
                key: (f.get_tensor(key).to(GET_DTYPE()) if unified_dtype or all(s not in key for s in sensitive_layer) else f.get_tensor(key).to(GET_SENSITIVE_DTYPE()))
                for key in f.keys()
                if not any(remove_key in key for remove_key in remove_keys) and (preserve_keys is None or any(preserve_key in key for preserve_key in preserve_keys))
            }

    def _load_ckpt(self, unified_dtype, sensitive_layer):
        """Load checkpoint weights.

        Args:
            unified_dtype: Whether to use unified dtype
            sensitive_layer: Dictionary of sensitive layer patterns

        Returns:
            dict: Dictionary of weights
        """
        _tp_dev = self.use_tp
        if _tp_dev:
            _saved_device, self.device = self.device, torch.device("cpu")

        safetensors_path = self.config.get("dit_original_ckpt") or self.config.get("transformer_model_path") or self.model_path

        if os.path.isdir(safetensors_path):
            if self.lazy_load:
                self.lazy_load_path = safetensors_path
                non_block_file = os.path.join(safetensors_path, "non_block.safetensors")
                if os.path.exists(non_block_file):
                    safetensors_files = [non_block_file]
                else:
                    raise ValueError(f"Non-block file not found in {safetensors_path}. Please check the model path.")
            else:
                safetensors_files = glob.glob(os.path.join(safetensors_path, "*.safetensors"))
        else:
            if self.lazy_load:
                self.lazy_load_path = safetensors_path
            safetensors_files = [safetensors_path]

        weight_dict = {}
        for file_path in safetensors_files:
            if self.config.get("adapter_model_path", None) is not None:
                if self.config["adapter_model_path"] == file_path:
                    continue
            logger.info(f"Loading weights from {file_path}")
            file_weights = self._load_safetensor_to_dict(file_path, unified_dtype, sensitive_layer)
            weight_dict.update(file_weights)

        if _tp_dev:
            self.device = _saved_device
        return weight_dict

    def _load_quant_ckpt(self, unified_dtype, sensitive_layer):
        """Load quantized checkpoint weights.

        Args:
            unified_dtype: Whether to use unified dtype
            sensitive_layer: Dictionary of sensitive layer patterns

        Returns:
            dict: Dictionary of weights
        """
        _tp_dev = self.use_tp
        if _tp_dev:
            _saved_device, self.device = self.device, torch.device("cpu")

        remove_keys = self.remove_keys if hasattr(self, "remove_keys") else []

        if self.config.get("dit_quantized_ckpt", None):
            safetensors_path = self.config["dit_quantized_ckpt"]
        else:
            safetensors_path = self.model_path

        # Handle GGUF format
        if "gguf" in self.config.get("dit_quant_scheme", ""):
            if os.path.isdir(safetensors_path):
                gguf_type = self.config.get("dit_quant_scheme").replace("gguf-", "")
                gguf_files = [path for path in glob.glob(os.path.join(safetensors_path, "*.gguf")) if gguf_type in os.path.basename(path)]
                if not gguf_files:
                    raise FileNotFoundError(f"No GGUF file matching {gguf_type} in {safetensors_path}. Set dit_quantized_ckpt to the checkpoint file.")
                if len(gguf_files) > 1:
                    raise ValueError(f"Multiple GGUF files matching {gguf_type} in {safetensors_path}. Set dit_quantized_ckpt to the checkpoint file.")
                gguf_path = gguf_files[0]
            else:
                gguf_path = safetensors_path
            weight_dict = self._load_gguf_ckpt(gguf_path)
            if _tp_dev:
                self.device = _saved_device
            return weight_dict

        if os.path.isdir(safetensors_path):
            if self.lazy_load:
                self.lazy_load_path = safetensors_path
                non_block_file = os.path.join(safetensors_path, "non_block.safetensors")
                if os.path.exists(non_block_file):
                    safetensors_files = [non_block_file]
                else:
                    raise ValueError(f"Non-block file not found in {safetensors_path}. Please check the model path.")
            else:
                safetensors_files = glob.glob(os.path.join(safetensors_path, "*.safetensors"))
        else:
            if self.lazy_load:
                self.lazy_load_path = safetensors_path
            safetensors_files = [safetensors_path]
            safetensors_path = os.path.dirname(safetensors_path)

        weight_dict = {}
        for safetensor_path in safetensors_files:
            with safe_open(safetensor_path, framework="pt") as f:
                self._record_checkpoint_metadata(f)
                logger.info(f"Loading weights from {safetensor_path}")
                for k in f.keys():
                    if any(remove_key in k for remove_key in remove_keys):
                        continue
                    if self.config.get("dit_quant_scheme") == "int8-metal" and k.endswith(".weight_scale"):
                        weight_dict[k] = f.get_tensor(k).to(device=self.device, dtype=torch.float32)
                    elif f.get_tensor(k).dtype in [torch.float16, torch.bfloat16, torch.float]:
                        if unified_dtype or all(s not in k for s in sensitive_layer):
                            weight_dict[k] = f.get_tensor(k).to(GET_DTYPE()).to(self.device)
                        else:
                            weight_dict[k] = f.get_tensor(k).to(GET_SENSITIVE_DTYPE()).to(self.device)
                    else:
                        weight_dict[k] = f.get_tensor(k).to(self.device)

        # Load calibration data for nvfp4
        if self.config.get("dit_quant_scheme", "Default") == "nvfp4":
            calib_path = os.path.join(safetensors_path, "calib.pt")
            if os.path.exists(calib_path):
                logger.info(f"[CALIB] Loaded calibration data from: {calib_path}")
                calib_data = torch.load(calib_path, map_location="cpu")
                for k, v in calib_data["absmax"].items():
                    weight_dict[k.replace(".weight", ".input_absmax")] = v.to(self.device)

        if _tp_dev:
            self.device = _saved_device
        return weight_dict

    def _load_gguf_ckpt(self, gguf_path):
        """Load GGUF checkpoint.

        Args:
            gguf_path: Path to GGUF file or directory

        Returns:
            dict: Dictionary of weights
        """
        state_dict = load_gguf_sd_ckpt(gguf_path, to_device=self.device)
        return state_dict

    def _load_weights_from_rank0(self, weight_dict, is_weight_loader):
        """Load and distribute weights from rank 0 to all ranks.

        This is a basic implementation. Subclasses may override for more
        sophisticated distribution (e.g., tensor parallel).

        Args:
            weight_dict: Weight dictionary from rank 0
            is_weight_loader: Whether current rank is the weight loader

        Returns:
            dict: Distributed weight dictionary
        """
        logger.info("Loading distributed weights")
        global_src_rank = 0
        target_device = "cpu" if self.cpu_offload else "cuda"

        if is_weight_loader:
            meta_dict = {}
            for key, tensor in weight_dict.items():
                meta_dict[key] = {"shape": tensor.shape, "dtype": tensor.dtype}

            obj_list = [meta_dict]
            dist.broadcast_object_list(obj_list, src=global_src_rank)
            synced_meta_dict = obj_list[0]
        else:
            obj_list = [None]
            dist.broadcast_object_list(obj_list, src=global_src_rank)
            synced_meta_dict = obj_list[0]

        distributed_weight_dict = {}
        for key, meta in synced_meta_dict.items():
            distributed_weight_dict[key] = torch.empty(meta["shape"], dtype=meta["dtype"], device=target_device)

        if target_device == "cuda":
            dist.barrier(device_ids=[torch.cuda.current_device()])

        for key in sorted(synced_meta_dict.keys()):
            if is_weight_loader:
                distributed_weight_dict[key].copy_(weight_dict[key], non_blocking=True)

            if target_device == "cpu":
                if is_weight_loader:
                    gpu_tensor = distributed_weight_dict[key].cuda()
                    dist.broadcast(gpu_tensor, src=global_src_rank)
                    distributed_weight_dict[key].copy_(gpu_tensor.cpu(), non_blocking=True)
                    del gpu_tensor
                    torch.cuda.empty_cache()
                else:
                    gpu_tensor = torch.empty_like(distributed_weight_dict[key], device="cuda")
                    dist.broadcast(gpu_tensor, src=global_src_rank)
                    distributed_weight_dict[key].copy_(gpu_tensor.cpu(), non_blocking=True)
                    del gpu_tensor
                    torch.cuda.empty_cache()

                if distributed_weight_dict[key].is_pinned():
                    distributed_weight_dict[key].copy_(distributed_weight_dict[key], non_blocking=True)
            else:
                dist.broadcast(distributed_weight_dict[key], src=global_src_rank)

        if target_device == "cuda":
            torch.cuda.synchronize()
        else:
            for tensor in distributed_weight_dict.values():
                if tensor.is_pinned():
                    tensor.copy_(tensor, non_blocking=False)

        logger.info(f"Weights distributed across {dist.get_world_size()} devices on {target_device}")

        return distributed_weight_dict

    @abstractmethod
    @torch.no_grad()
    def _infer_cond_uncond(self, inputs, infer_condition=True):
        """Run conditional/unconditional inference.

        Args:
            inputs: Input dictionary
            infer_condition: Whether to infer condition

        Subclasses must implement this method.
        """
        pass

    @abstractmethod
    @torch.no_grad()
    def _seq_parallel_pre_process(self, pre_infer_out):
        """Pre-process for sequence parallel mode.

        Args:
            pre_infer_out: Output from pre-inference

        Returns:
            Processed pre_infer_out

        Subclasses must implement this method.
        """
        pass

    @abstractmethod
    @torch.no_grad()
    def _seq_parallel_post_process(self, x):
        """Post-process for sequence parallel mode.

        Args:
            x: Output from transformer inference

        Returns:
            Processed x

        Subclasses must implement this method.
        """
        pass

    def set_scheduler(self, scheduler):
        """Set the scheduler for all inference modules."""
        self.scheduler = scheduler
        self.pre_infer.set_scheduler(scheduler)
        self.transformer_infer.set_scheduler(scheduler)
        self.post_infer.set_scheduler(scheduler)

    def to_cpu(self):
        """Move all weights to CPU."""
        self.pre_weight.to_cpu()
        self.transformer_weights.to_cpu()
        if hasattr(self, "post_weight"):
            self.post_weight.to_cpu()

    def to_cuda(self):
        """Move all weights to CUDA."""
        self.pre_weight.to_cuda()
        self.transformer_weights.to_cuda()
        if hasattr(self, "post_weight"):
            self.post_weight.to_cuda()

    @abstractmethod
    @torch.no_grad()
    def infer(self, inputs):
        """Run inference.

        Args:
            inputs: Input dictionary

        Subclasses must implement this method.
        """
        pass
