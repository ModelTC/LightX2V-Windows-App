from .tensor import DefaultTensor
