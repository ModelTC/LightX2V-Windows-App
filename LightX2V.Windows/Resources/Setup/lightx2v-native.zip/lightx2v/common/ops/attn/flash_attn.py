import torch
from loguru import logger

try:
    from flash_attn import flash_attn_func as flash_attn_func_v2
    from flash_attn.flash_attn_interface import flash_attn_varlen_func as flash_attn_varlen_func_v2
except ImportError:
    logger.info("flash_attn2 not found, please install flash_attn2 first")
    flash_attn_func_v2 = None
    flash_attn_varlen_func_v2 = None

try:
    from flash_attn_interface import flash_attn_func as flash_attn_func_v3
    from flash_attn_interface import flash_attn_varlen_func as flash_attn_varlen_func_v3
except ImportError:
    logger.info("flash_attn3 not found, please install flash_attn3 first")
    flash_attn_func_v3 = None
    flash_attn_varlen_func_v3 = None

try:
    from flash_attn.cute import flash_attn_func as flash_attn_func_v4
    from flash_attn.cute.block_sparsity import BlockSparseTensorsTorch
except (ImportError, AttributeError) as exc:
    logger.info(f"FlashAttention 4 is unavailable: {exc}")
    flash_attn_func_v4 = None
    BlockSparseTensorsTorch = None


from lightx2v.utils import workload_stats
from lightx2v.utils.registry_factory import ATTN_WEIGHT_REGISTER

from .template import AttnWeightTemplate


@ATTN_WEIGHT_REGISTER("flash_attn2")
class FlashAttn2Weight(AttnWeightTemplate):
    def __init__(self):
        self.config = {}

    def apply(
        self,
        q,
        k,
        v,
        cu_seqlens_q=None,
        cu_seqlens_kv=None,
        max_seqlen_q=None,
        max_seqlen_kv=None,
        **kwargs,
    ):
        causal = kwargs.get("causal", False)
        softmax_scale = kwargs.get("softmax_scale", None)
        if len(q.shape) == 3:
            bs = 1
            total_seqlen = q.shape[0]
        elif len(q.shape) == 4:
            bs = q.shape[0]
            total_seqlen = bs * q.shape[1]

        if bs == 1:
            if len(q.shape) == 4:
                q, k, v = q.squeeze(0), k.squeeze(0), v.squeeze(0)
            if k.shape[0] > 256:
                # FA2's dense single-batch kernel can return NaNs for long KV on SM90.
                cu_q = torch.arange(2, device=q.device, dtype=torch.int32) * q.shape[0]
                cu_kv = torch.arange(2, device=k.device, dtype=torch.int32) * k.shape[0]
                x = flash_attn_varlen_func_v2(q, k, v, cu_q, cu_kv, q.shape[0], k.shape[0], softmax_scale=softmax_scale, causal=causal).reshape(total_seqlen, -1)
            else:
                x = flash_attn_func_v2(q.unsqueeze(0), k.unsqueeze(0), v.unsqueeze(0), softmax_scale=softmax_scale, causal=causal).reshape(total_seqlen, -1)
        else:
            if cu_seqlens_q.is_cpu:
                cu_seqlens_q = cu_seqlens_q.to(q.device, non_blocking=True)
            if cu_seqlens_kv.is_cpu:
                cu_seqlens_kv = cu_seqlens_kv.to(k.device, non_blocking=True)
            if len(q.shape) == 4:
                q = q.reshape(-1, q.shape[-2], q.shape[-1])
                k = k.reshape(-1, k.shape[-2], k.shape[-1])
                v = v.reshape(-1, v.shape[-2], v.shape[-1])
            x = flash_attn_varlen_func_v2(
                q,
                k,
                v,
                cu_seqlens_q,
                cu_seqlens_kv,
                max_seqlen_q,
                max_seqlen_kv,
                softmax_scale=softmax_scale,
                causal=causal,
            ).reshape(total_seqlen, -1)

        return x

    def apply_with_lse(self, q, k, v, softmax_scale=None):
        """Apply one dense attention block and return LSE as [tokens, heads]."""
        if flash_attn_func_v2 is None:
            raise ImportError("FlashAttention2 is not installed.")
        if q.ndim == 3:
            q, k, v = q.unsqueeze(0), k.unsqueeze(0), v.unsqueeze(0)
        elif q.ndim != 4:
            raise ValueError(f"Dense FlashAttention2 expects 3D or 4D Q/K/V, got q.ndim={q.ndim}.")

        if q.shape[0] == 1 and k.shape[1] > 256:
            cu_q = torch.arange(2, device=q.device, dtype=torch.int32) * q.shape[1]
            cu_kv = torch.arange(2, device=k.device, dtype=torch.int32) * k.shape[1]
            output, lse, *_ = flash_attn_varlen_func_v2(
                q.squeeze(0),
                k.squeeze(0),
                v.squeeze(0),
                cu_q,
                cu_kv,
                q.shape[1],
                k.shape[1],
                softmax_scale=softmax_scale,
                causal=False,
                return_attn_probs=True,
            )
            return output.reshape(q.shape[1], -1), lse.transpose(0, 1)

        output, lse, *_ = flash_attn_func_v2(
            q.contiguous(),
            k.contiguous(),
            v.contiguous(),
            softmax_scale=softmax_scale,
            causal=False,
            return_attn_probs=True,
        )
        output = output.reshape(q.shape[0] * q.shape[1], -1)
        lse = lse.transpose(1, 2).reshape(q.shape[0] * q.shape[1], q.shape[2])
        return output, lse


@ATTN_WEIGHT_REGISTER("flash_attn2_varlen")
class FlashAttn2VarlenWeight(FlashAttn2Weight):
    def apply(
        self,
        q,
        k,
        v,
        cu_seqlens_q=None,
        cu_seqlens_kv=None,
        max_seqlen_q=None,
        max_seqlen_kv=None,
        **kwargs,
    ):
        causal = kwargs.get("causal", False)
        softmax_scale = kwargs.get("softmax_scale", None)
        total_seqlen = q.shape[0] if q.ndim == 3 else q.shape[0] * q.shape[1]

        if cu_seqlens_q is not None:
            cu_seqlens_q = cu_seqlens_q.to(q.device, non_blocking=True)
            cu_seqlens_kv = cu_seqlens_kv.to(k.device, non_blocking=True)
            if q.ndim == 4:
                q = q.reshape(-1, q.shape[-2], q.shape[-1])
                k = k.reshape(-1, k.shape[-2], k.shape[-1])
                v = v.reshape(-1, v.shape[-2], v.shape[-1])
            x = flash_attn_varlen_func_v2(
                q,
                k,
                v,
                cu_seqlens_q,
                cu_seqlens_kv,
                max_seqlen_q,
                max_seqlen_kv,
                softmax_scale=softmax_scale,
                causal=causal,
            )
        else:
            if q.ndim == 3:
                q = q.unsqueeze(0)
                k = k.unsqueeze(0)
                v = v.unsqueeze(0)
            x = flash_attn_func_v2(q, k, v, softmax_scale=softmax_scale, causal=causal)

        return x.reshape(total_seqlen, -1)


@ATTN_WEIGHT_REGISTER("flash_attn3")
class FlashAttn3Weight(AttnWeightTemplate):
    def __init__(self):
        self.config = {}

    def apply(
        self,
        q,
        k,
        v,
        cu_seqlens_q=None,
        cu_seqlens_kv=None,
        max_seqlen_q=None,
        max_seqlen_kv=None,
        **kwargs,
    ):
        causal = kwargs.get("causal", False)
        softmax_scale = kwargs.get("softmax_scale", None)
        if len(q.shape) == 3:
            bs = 1
            total_seqlen = q.shape[0]
        elif len(q.shape) == 4:
            bs = q.shape[0]
            total_seqlen = bs * q.shape[1]

        if bs == 1:
            if len(q.shape) == 3:
                q = q.unsqueeze(0)
                k = k.unsqueeze(0)
                v = v.unsqueeze(0)
            x = flash_attn_func_v3(q, k, v, softmax_scale=softmax_scale, causal=causal).reshape(total_seqlen, -1)
        else:
            if cu_seqlens_q.is_cpu:
                cu_seqlens_q = cu_seqlens_q.to(q.device, non_blocking=True)
            if cu_seqlens_kv.is_cpu:
                cu_seqlens_kv = cu_seqlens_kv.to(k.device, non_blocking=True)
            if len(q.shape) == 4:
                q = q.reshape(-1, q.shape[-2], q.shape[-1])
                k = k.reshape(-1, k.shape[-2], k.shape[-1])
                v = v.reshape(-1, v.shape[-2], v.shape[-1])
            x = flash_attn_varlen_func_v3(
                q,
                k,
                v,
                cu_seqlens_q,
                cu_seqlens_kv,
                max_seqlen_q,
                max_seqlen_kv,
                softmax_scale=softmax_scale,
                causal=causal,
            ).reshape(total_seqlen, -1)

        return x

    def apply_with_lse(self, q, k, v, softmax_scale=None):
        """Apply one dense attention block and return LSE as [tokens, heads]."""
        if flash_attn_func_v3 is None:
            raise ImportError("FlashAttention3 is not installed.")
        if q.ndim == 3:
            q, k, v = q.unsqueeze(0), k.unsqueeze(0), v.unsqueeze(0)
        elif q.ndim != 4:
            raise ValueError(f"Dense FlashAttention3 expects 3D or 4D Q/K/V, got q.ndim={q.ndim}.")

        output, lse, *_ = flash_attn_func_v3(
            q.contiguous(),
            k.contiguous(),
            v.contiguous(),
            softmax_scale=softmax_scale,
            causal=False,
            return_attn_probs=True,
        )
        output = output.reshape(q.shape[0] * q.shape[1], -1)
        lse = lse.transpose(1, 2).reshape(q.shape[0] * q.shape[1], q.shape[2])
        return output, lse


@ATTN_WEIGHT_REGISTER("flash_attn4")
class FlashAttn4Weight(AttnWeightTemplate):
    def __init__(self):
        self.config = {}

    def apply(
        self,
        q,
        k,
        v,
        cu_seqlens_q=None,
        cu_seqlens_kv=None,
        max_seqlen_q=None,
        max_seqlen_kv=None,
        **kwargs,
    ):
        if len(q.shape) == 3:
            bs = 1
            q, k, v = q.unsqueeze(0), k.unsqueeze(0), v.unsqueeze(0)
        elif len(q.shape) == 4:
            bs = q.shape[0]
        assert bs == 1, "flash_attn4 doesn't support flash_attn_varlen_func now. Just use it for batchsize = 1 for sure."
        x, _ = flash_attn_func_v4(
            q,
            k,
            v,
        )
        x = x.reshape(q.shape[1], -1)
        return x


@ATTN_WEIGHT_REGISTER("spas_flash_attn4")
class SparseFlashAttn4Weight(AttnWeightTemplate):
    sparsity_ratio = 0.8
    sparse_mode = "sla_mode"

    def __init__(self):
        from .utils.sla_util import get_block_map
        from .utils.sparge_util import block_map_ordinal_lut_triton, get_block_map_meansim

        self._block_map_ordinal_lut_triton = block_map_ordinal_lut_triton
        self._get_block_map = get_block_map
        self._get_block_map_meansim = get_block_map_meansim
        self.config = {}
        self.topk = 1 - self.sparsity_ratio
        self.BLKQ, self.BLKK = 128, 128

    def apply(
        self,
        q,
        k,
        v,
        cu_seqlens_q=None,
        cu_seqlens_kv=None,
        max_seqlen_q=None,
        max_seqlen_kv=None,
        **kwargs,
    ):
        if len(q.shape) == 3:
            bs = 1
            q, k, v = q.unsqueeze(0), k.unsqueeze(0), v.unsqueeze(0)
        elif len(q.shape) == 4:
            bs = q.shape[0]
        assert bs == 1, "flash_attn4 doesn't support flash_attn_varlen_func now. Just use it for batchsize = 1 for sure."

        # (L, H, D) -> (B, L, H, D)
        qt = q.transpose(1, 2).contiguous()
        kt = k.transpose(1, 2).contiguous()
        if self.sparse_mode == "sla_mode":
            sparse_map, lut, real_topk = self._get_block_map(qt, kt, topk_ratio=self.topk, BLKQ=self.BLKQ, BLKK=self.BLKK)
        elif self.sparse_mode == "sparge_mode":
            smooth_k = kt - kt.mean(dim=-2, keepdim=True)
            sparse_map = self._get_block_map_meansim(qt, smooth_k, cdfthreshd=None, topk=self.topk, return_lut=False, BLKQ=self.BLKQ, BLKK=self.BLKK)
        else:
            logger.info(f"spas_flash_attn4 sparse_mode only support sla_mode and sparge_mode now.")

        # (B, H, Q_block_num, K_block_num)
        full_block_idx, full_block_cnt = self._block_map_ordinal_lut_triton(sparse_map)
        mask_block_cnt = torch.zeros_like(full_block_cnt)
        mask_block_idx = torch.zeros_like(full_block_idx)
        block_sparse_tensors = BlockSparseTensorsTorch(
            mask_block_cnt=mask_block_cnt,
            mask_block_idx=mask_block_idx,
            full_block_cnt=full_block_cnt,
            full_block_idx=full_block_idx,
            block_size=(self.BLKQ, self.BLKK),
        )

        x, _ = flash_attn_func_v4(
            q=q,
            k=k,
            v=v,
            block_sparse_tensors=block_sparse_tensors,
        )

        if workload_stats.enabled("attention"):
            workload_stats.record_sparse_attn(q, k, v, sparse_map, self.BLKQ, self.BLKK, operator="spas_flash_attn4", layout="BSHD")
        x = x.reshape(bs * max_seqlen_q, -1)
        return x
